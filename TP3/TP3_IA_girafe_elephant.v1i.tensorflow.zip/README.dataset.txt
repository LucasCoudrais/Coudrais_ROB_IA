# TP3_IA_girafe_elephant > 2023-11-07 3:06pm
https://universe.roboflow.com/robia/tp3_ia_girafe_elephant

Provided by a Roboflow user
License: CC BY 4.0

